**Falcon-Diagnostic Script**

When to use this script:
For any issue that you intend to contact support for where the sensor is running on a Linux distro.

Directions:
- Transfer the file to the host in question, open the terminal and run the following command in the same directory as the file:
- # chmod u+x falcon_diagnostic_3.11.1.sh
- Run the script: sudo ./falcon_diagnostic_3.11.1.sh
- It gathers information on the sensor status, and some other basics about the system. Usually takes 1-2 minutes to complete.
- It will create a directory "crowdstrike_diagnostics" in the folder that the script is ran from and will compress the results into a .bzip file.

What it does:
1. Creates a “crowdstrike_diagnostics” working directory to operate out of.
2. Detects if script is being run as root.
3. Identify the operating system in use.
4. Collects syslog.
5. Collects dmesg.
6. Gathers the CID the sensor is licensed with, and the AID (AgentID or Host ID) the sensor has been assigned.
7. Checks if Falcon Sensor is running. If not running, collects the service status.
8. Collects the sensor version.
9. Checks the installed RPM package info from the RPM/DPKG database.
10. Check’s falcon-sensor status.
11. Verify’s the sensor’s files on disk.
12. Check’s the system’s kernel modules to verify sensor’s kernel modules are running.
13. Checks if the running kernel is supported.
14. Collects the SHA256 hash of each file in the CrowdStrike directory.
15. Checks status of SELinux (RHEL/CentOS/SLES)
16. Checks status of App Armor (Ubuntu)
17. Verifies sensor is connected to the cloud
18. Verifies sensor’s proxy status
19. Checks installed OpenSSL versions and attempts connection
20. Checks IP tables for any custom routing rules that might interfere
21. Checks disk space
22. Checks CPU and IO info
23. Checks memory info
24. Checks process info
25. Checks how much memory the sensor is using per CPU thread
26. Packages all of the collected information into a compressed archive.

Improvements added in falcon_diagnostic_3.11.1.sh:
Changes:
	- Added Cgroup memory information collection. 

Warning/Considerations:
* When collecting the additional extended information, some distros may not support some of the commands or the required packages may not be installed. This is expected behavior.

Note: Sometimes if you open the script in a Windows Word Processor or within Outlook it can cause the addition of carriage return characters that will prevent the script from running properly on a Linux host. If you open the script on a Windows host to look at the contents, please be advised that you'll want to delete that copy and re-download it without opening it to ensure it works on your Linux host.

SHA256SUM:
8373cb96cafd55bb09870fa022a158fd0278fbd5e815a2bf2c561298b58c843c